import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Services.Pipewire

PanelWindow {
    id: panel

    anchors {
        top: true
        right: true
    }

    width: 1
    height: 1
    color: "transparent"
    visible: false

    IpcHandler {
        target: "audio"

        function toggle(): void {
            popup.visible = !popup.visible
        }
    }

    PopupWindow {
        id: popup

        anchor.window: panel
        anchor.rect.x: 0
        anchor.rect.y: 35

        width: 360
        height: 300

        visible: false
        grabFocus: true

        Rectangle {
            anchors.fill: parent
            radius: 12
            color: "#202020"
            border.color: "#404040"
            border.width: 1

            Column {
                anchors.fill: parent
                anchors.margins: 18
                spacing: 12

                Text {
                    text: "Output device"
                    color: "white"
                    font.pixelSize: 18
                    font.bold: true
                }

                Repeater {
                    model: Pipewire.nodes.values.filter(
                        node => node.isSink && !node.isStream && node.audio
                    )

                    delegate: Rectangle {
                        width: 324
                        height: 55
                        radius: 8

                        color: modelData === Pipewire.defaultAudioSink
                            ? "#3a3a3a"
                            : "#292929"

                        Text {
                            anchors.left: parent.left
                            anchors.leftMargin: 15
                            anchors.verticalCenter: parent.verticalCenter

                            width: parent.width - 30

                            text: modelData.description ||
                                  modelData.nickname ||
                                  modelData.name

                            color: "white"
                            elide: Text.ElideRight
                            font.pixelSize: 15
                        }

                        MouseArea {
                            anchors.fill: parent

                            onClicked: {
                                Pipewire.preferredDefaultAudioSink = modelData
                                popup.visible = false
                            }
                        }
                    }
                }
            }
        }
    }
}
