if status is-interactive
set -g fish_greeting
fastfetch

zoxide init fish | source
# Commands to run in interactive sessions can go here
end
