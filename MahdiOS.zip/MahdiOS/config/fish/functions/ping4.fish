function ping4 --wraps='ping 4.2.2.4' --description 'alias ping4 ping 4.2.2.4'
    ping 4.2.2.4 $argv
end
