function system-update --wraps='sudo pacman -Syu' --description 'alias system-update sudo pacman -Syu'
    sudo pacman -Syu $argv
end
