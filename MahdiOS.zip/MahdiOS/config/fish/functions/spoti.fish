function spoti --wraps='cliamp --provider spotify' --description 'alias spoti cliamp --provider spotify'
    cliamp --provider spotify $argv
end
