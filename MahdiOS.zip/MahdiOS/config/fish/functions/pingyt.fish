function pingyt --wraps='ping youtube.com' --description 'alias pingyt ping youtube.com'
    ping youtube.com $argv
end
