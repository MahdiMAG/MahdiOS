#!/bin/bash

connected=$(bluetoothctl devices Connected 2>/dev/null)

if [ -z "$connected" ]; then
    echo "No connected devices"
else
    echo "$connected" | while read -r _ mac name; do
        echo "$name"
    done
fi
