
#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
failed=0
declare -A seen=()

for manifest in "$PROJECT_DIR"/packages/*.txt; do
    [[ -f "$manifest" ]] || continue

    while IFS= read -r package || [[ -n "$package" ]]; do
        # Remove comments and surrounding whitespace.
        package="${package%%#*}"
        package="${package#"${package%%[![:space:]]*}"}"
        package="${package%"${package##*[![:space:]]}"}"
        [[ -n "$package" ]] || continue

        if [[ -n "${seen[$package]+yes}" ]]; then
            printf 'DUPLICATE: %s\n' "$package"
            failed=1
            continue
        fi
        seen["$package"]=1

        if [[ "$manifest" == */aur.txt ]]; then
            printf 'AUR entry: %s (checked separately)\n' "$package"
        elif pacman -Si "$package" >/dev/null 2>&1; then
            printf 'OK: %s\n' "$package"
        else
            printf 'NOT FOUND in official repositories: %s\n' "$package"
            failed=1
        fi
    done < "$manifest"
done

if (( failed )); then
    printf '\nManifest validation failed. Review the entries above.\n' >&2
    exit 1
fi

printf '\nManifest validation passed.\n'
