
#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ $# -ne 1 ]]; then
    printf 'Usage: %s <manifest-name>\n' "$0" >&2
    printf 'Example: %s desktop.txt\n' "$0" >&2
    exit 2
fi

manifest_name="$1"

# Accept only a filename, not an arbitrary path.
[[ "$manifest_name" != */* && "$manifest_name" == *.txt ]] || {
    printf 'ERROR: Supply a manifest filename such as desktop.txt\n' >&2
    exit 1
}

MANIFEST="$PROJECT_DIR/packages/$manifest_name"

[[ -f "$MANIFEST" ]] || {
    printf 'ERROR: Manifest not found: %s\n' "$MANIFEST" >&2
    exit 1
}

[[ "$EUID" -ne 0 ]] || {
    printf 'ERROR: Run this script as your regular user, not as root.\n' >&2
    exit 1
}

mapfile -t packages < <(
    sed 's/#.*//' "$MANIFEST" |
    awk '{$1=$1}; NF {print $1}'
)

((${#packages[@]})) || {
    printf 'ERROR: No packages found in %s\n' "$manifest_name" >&2
    exit 1
}

printf '\nMahdiOS — Install manifest: %s\n\n' "$manifest_name"
printf 'Packages to install or update:\n'
printf '  %s\n' "${packages[@]}"
printf '\n'

read -r -p 'Continue? [y/N] ' answer
[[ "$answer" == [yY] || "$answer" == [yY][eE][sS] ]] || {
    printf 'Cancelled. No changes made.\n'
    exit 0
}

sudo pacman -S --needed -- "${packages[@]}"

printf '\nInstallation command completed for %s.\n' "$manifest_name"
