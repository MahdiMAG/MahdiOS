
#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
SOURCE_DIR="$PROJECT_DIR/config"
TARGET_DIR="$HOME/.config"

fail() {
    printf 'ERROR: %s\n' "$*" >&2
    exit 1
}

[[ "$EUID" -ne 0 ]] ||
    fail "Run this script as your regular user, not as root."

[[ -d "$SOURCE_DIR" ]] ||
    fail "Configuration source directory not found: $SOURCE_DIR"

mkdir -p -- "$TARGET_DIR"

printf '\nMahdiOS — Deploy configuration files\n\n'
printf 'Source:      %s\n' "$SOURCE_DIR"
printf 'Destination: %s\n\n' "$TARGET_DIR"
printf 'Existing files with matching names may be overwritten.\n'

read -r -p 'Continue? [y/N] ' answer
[[ "$answer" == [yY] || "$answer" == [yY][eE][sS] ]] || {
    printf 'Cancelled. No changes made.\n'
    exit 0
}

cp -a -- "$SOURCE_DIR/." "$TARGET_DIR/"

printf '\nConfiguration deployment completed.\n'
