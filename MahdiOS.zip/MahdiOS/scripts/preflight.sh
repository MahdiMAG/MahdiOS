
#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"

printf '\nMahdiOS 1.0 — Preflight checks\n'
printf '%s\n\n' '-------------------------------'

fail() {
    printf 'ERROR: %s\n' "$*" >&2
    exit 1
}

# 1. Verify the operating system.
[[ -r /etc/arch-release ]] ||
    fail "This installer must run on an installed Arch Linux system."

# 2. Verify required commands.
for cmd in pacman sudo bash; do
    command -v "$cmd" >/dev/null 2>&1 ||
        fail "Required command not found: $cmd"
done

# 3. Require a regular user, not a root login.
[[ "$EUID" -ne 0 ]] ||
    fail "Run this script as your regular user, not as root."

# 4. Verify sudo authorization.
sudo -v ||
    fail "Sudo authorization failed. Configure sudo before continuing."

# 5. Verify project manifests exist.
manifests=(
    packages/core.txt
    packages/desktop.txt
    packages/apps.txt
    packages/development.txt
    packages/optional.txt
    packages/services.txt
    packages/utilities.txt
    packages/aur.txt
)

for manifest in "${manifests[@]}"; do
    [[ -f "$PROJECT_DIR/$manifest" ]] ||
        fail "Missing manifest: $manifest"
done

# 6. Check internet connectivity.
if command -v curl >/dev/null 2>&1; then
    curl --fail --silent --show-error \
        --connect-timeout 5 --max-time 10 \
        https://www.google.com/ -o /dev/null ||
        fail "Cannot reach https://www.google.com/. Check your network and DNS settings."
elif command -v ping >/dev/null 2>&1; then
    ping -c 1 -W 5 google.com >/dev/null 2>&1 ||
        fail "Cannot reach google.com. Check your network and DNS settings."
else
    printf 'WARNING: Neither curl nor ping is installed; skipping connectivity check.\n'
fi

# 7. Check Arch repository access.
pacman -Si base >/dev/null 2>&1 ||
    fail "Cannot query the Arch repositories. Check your network and pacman databases."


printf 'PASS: Arch Linux detected\n'
printf 'PASS: Required commands available\n'
printf 'PASS: Running as a regular user\n'
printf 'PASS: Sudo authorization successful\n'
printf 'PASS: All package manifests found\n'
printf 'PASS: Internet connectivity to google.com\n'
printf 'PASS: Arch repository query successful\n'
printf '\nPreflight complete. No system changes were made.\n'
