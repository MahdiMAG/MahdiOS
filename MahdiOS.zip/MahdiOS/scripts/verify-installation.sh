
#!/usr/bin/env bash
set -uo pipefail

PASS=0
WARN=0
FAIL=0

pass() {
    printf '[PASS] %s\n' "$1"
    ((PASS += 1))
}

warn() {
    printf '[WARN] %s\n' "$1"
    ((WARN += 1))
}

fail() {
    printf '[FAIL] %s\n' "$1"
    ((FAIL += 1))
}

check_command() {
    if command -v "$1" >/dev/null 2>&1; then
        pass "Command available: $1"
    else
        fail "Command missing: $1"
    fi
}

check_file() {
    if [[ -f "$1" ]]; then
        pass "File exists: $1"
    else
        fail "File missing: $1"
    fi
}

check_optional_file() {
    if [[ -f "$1" ]]; then
        pass "File exists: $1"
    else
        warn "Optional file missing: $1"
    fi
}

printf '\nMahdiOS — Installation Verification\n'
printf '%s\n\n' '==================================='

# Operating system
if [[ -r /etc/arch-release ]]; then
    pass "Arch Linux detected"
else
    fail "Arch Linux release file not found"
fi

# Core commands
printf '\n--- Core commands ---\n'
for cmd in pacman sudo git fish; do
    check_command "$cmd"
done

# Desktop commands
printf '\n--- Desktop commands ---\n'
for cmd in niri dms alacritty fuzzel; do
    check_command "$cmd"
done

# Main configuration
printf '\n--- Configuration files ---\n'
check_file "$HOME/.config/niri/config.kdl"
check_file "$HOME/.config/niri/dms/windowrules.kdl"
check_file "$HOME/.config/fish/config.fish"
check_file "$HOME/.config/alacritty/alacritty.toml"
check_file "$HOME/.config/DankMaterialShell/settings.json"

# Optional configuration
check_optional_file "$HOME/.config/waybar/config.jsonc"
check_optional_file "$HOME/.config/fastfetch/config.jsonc"

# User service
printf '\n--- DankMaterialShell service ---\n'
if systemctl --user is-enabled dms.service >/dev/null 2>&1; then
    pass "dms.service is enabled"
else
    warn "dms.service is not enabled for this user"
fi

if systemctl --user is-active dms.service >/dev/null 2>&1; then
    pass "dms.service is active"
else
    warn "dms.service is not currently active"
fi

# System services
printf '\n--- System services ---\n'
for service in NetworkManager.service bluetooth.service; do
    if systemctl is-enabled "$service" >/dev/null 2>&1; then
        pass "$service is enabled"
    else
        warn "$service is not enabled"
    fi
done

# Login shell
printf '\n--- Login shell ---\n'
if command -v fish >/dev/null 2>&1; then
    fish_path="$(command -v fish)"
    if grep -Fxq "$fish_path" /etc/shells; then
        pass "Fish is listed in /etc/shells"
    else
        warn "Fish is not listed in /etc/shells"
    fi

    if [[ "${SHELL:-}" == "$fish_path" ]]; then
        pass "Fish is the current user's configured shell"
    else
        warn "Fish is installed but may not be the configured login shell"
    fi
fi

# DMS greeter is optional because its installation is interactive.
printf '\n--- Login greeter ---\n'
if command -v dms-greeter >/dev/null 2>&1; then
    pass "DMS greeter command is available"
else
    warn "DMS greeter not found; check your chosen login setup"
fi

printf '\n--- Summary ---\n'
printf 'PASS: %d\nWARN: %d\nFAIL: %d\n' "$PASS" "$WARN" "$FAIL"

if (( FAIL > 0 )); then
    printf '\nVerification finished with failures.\n'
    exit 1
fi

printf '\nNo required checks failed. Review warnings above.\n'
