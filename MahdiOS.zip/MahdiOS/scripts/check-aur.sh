
#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
MANIFEST="$PROJECT_DIR/packages/aur.txt"

command -v curl >/dev/null 2>&1 || {
    printf 'ERROR: curl is required for AUR checks.\n' >&2
    exit 1
}

[[ -f "$MANIFEST" ]] || {
    printf 'ERROR: Missing manifest: %s\n' "$MANIFEST" >&2
    exit 1
}

failed=0

while IFS= read -r package || [[ -n "$package" ]]; do
    package="${package%%#*}"
    package="${package#"${package%%[![:space:]]*}"}"
    package="${package%"${package##*[![:space:]]}"}"
    [[ -n "$package" ]] || continue

    if ! response="$(curl --fail --silent --show-error \
        --connect-timeout 5 --max-time 15 \
        --get --data-urlencode "arg[]=$package" \
        https://aur.archlinux.org/rpc/v5/info 2>/dev/null)"; then
        printf 'ERROR: Could not query AUR for %s\n' "$package"
        failed=1
        continue
    fi

    if [[ "$response" == *'"resultcount":0'* ]]; then
        printf 'NOT FOUND on AUR: %s\n' "$package"
        failed=1
    elif [[ "$response" == *'"Name":"'"$package"'"'* ]]; then
        printf 'FOUND on AUR: %s\n' "$package"
    else
        printf 'ERROR: Unexpected AUR response for %s\n' "$package"
        failed=1
    fi
done < "$MANIFEST"

if (( failed )); then
    printf '\nAUR validation failed or was incomplete.\n' >&2
    exit 1
fi

printf '\nAUR package lookup passed.\n'
