```bash
#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
MANIFEST="$PROJECT_DIR/packages/aur.txt"

fail() {
    printf 'ERROR: %s\n' "$*" >&2
    exit 1
}

[[ "$EUID" -ne 0 ]] ||
    fail "Run this script as your regular user, not as root."

[[ -f "$MANIFEST" ]] ||
    fail "Missing manifest: $MANIFEST"

command -v git >/dev/null 2>&1 ||
    fail "git is required. Install it before running this stage."

command -v makepkg >/dev/null 2>&1 ||
    fail "makepkg is unavailable. Install base-devel before running this stage."

mapfile -t packages < <(
    sed 's/#.*//' "$MANIFEST" |
    awk '{$1=$1}; NF {print $1}'
)

((${#packages[@]})) ||
    fail "The AUR manifest contains no packages."

# yay is bootstrapped separately if it appears in the manifest.
has_yay=0
other_packages=()

for package in "${packages[@]}"; do
    if [[ "$package" == "yay" ]]; then
        has_yay=1
    else
        other_packages+=("$package")
    fi
done

(( has_yay )) ||
    fail "packages/aur.txt must include yay for this installer design."

printf '\nMahdiOS — AUR package installation\n\n'
printf 'AUR packages in this stage:\n'
printf '  %s\n' "${packages[@]}"
printf '\nAUR packages contain user-submitted build instructions.\n'
printf 'Review build files and package changes before accepting them.\n\n'

read -r -p 'Start the AUR installation stage? [y/N] ' answer
[[ "$answer" == [yY] || "$answer" == [yY][eE][sS] ]] || {
    printf 'Cancelled. No changes made by this script.\n'
    exit 0
}

# Bootstrap yay only when it is not already installed.
if ! command -v yay >/dev/null 2>&1; then
    build_dir="$(mktemp -d "${TMPDIR:-/tmp}/mah dios-yay.XXXXXX" 2>/dev/null)" ||
        build_dir="$(mktemp -d "${TMPDIR:-/tmp}/mahdios-yay.XXXXXX")"

    trap 'rm -rf -- "$build_dir"' EXIT
command -v less >/dev/null 2>&1 ||
    fail "less is required to review the yay PKGBUILD."

    printf '\nCloning the yay AUR repository...\n' git clone 
    https://aur.archlinux.org/yay.git "$build_dir/yay"

    printf '\nReview the PKGBUILD and build files before continuing.\n'
    cd "$build_dir/yay"
    less PKGBUILD
    read -r -p 'Build and install yay? [y/N] ' yay_answer
    [[ "$yay_answer" == [yY] || "$yay_answer" == [yY][eE][sS] ]] || {
        printf 'yay installation cancelled.\n'
        exit 1
    }

    makepkg -si
    cd "$PROJECT_DIR"
else
    printf '\nyay is already installed; skipping bootstrap.\n'
fi

if ((${#other_packages[@]})); then
    printf '\nInstalling the remaining AUR packages...\n'
    yay -S --needed -- "${other_packages[@]}"
else
    printf '\nNo additional AUR packages to install.\n'
fi

printf '\nAUR installation stage completed.\n'
```
