
#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
SCRIPTS_DIR="$PROJECT_DIR/scripts"

fail() {
    printf '\nERROR: %s\n' "$*" >&2
    exit 1
}

run_stage() {
    local script="$1"

    [[ -f "$SCRIPTS_DIR/$script" ]] ||
        fail "Required script not found: $SCRIPTS_DIR/$script"

    printf '\n\n========================================\n'
    printf 'MahdiOS — Stage: %s\n' "$script"
    printf '========================================\n\n'

    bash "$SCRIPTS_DIR/$script"

    printf '\nCompleted: %s\n' "$script"
}

run_manifest() {
    local manifest="$1"
    bash "$SCRIPTS_DIR/install-manifest.sh" "$manifest"
}

printf '\n'
printf '========================================\n'
printf '          MahdiOS Installer\n'
printf '========================================\n'
printf '\n'
printf 'Project directory: %s\n\n' "$PROJECT_DIR"
printf 'This script runs the installation stages in sequence.\n'
printf 'A stage failure stops the main installer.\n\n'

read -r -p 'Start MahdiOS installation? [y/N] ' answer
[[ "$answer" == [yY] || "$answer" == [yY][eE][sS] ]] || {
    printf 'Installation cancelled.\n'
    exit 0
}

# 1. Preflight
run_stage "preflight.sh"

# 2. Check official-repository package names
run_stage "check-packages.sh"

# 3. Check AUR package names
run_stage "check-aur.sh"

# 4. Install core packages
run_stage "install-core.sh"

# 5. Install the remaining official-repository manifests
for manifest in \
    desktop.txt \
    apps.txt \
    development.txt \
    services.txt \
    utilities.txt \
    optional.txt
do
    run_manifest "$manifest"
done

# 6. Install AUR packages
run_stage "install-aur.sh"

# 7. Enable system services
run_stage "enable-services.sh"

# 8. Install desktop dependencies and run the DMS installer
run_stage "install-desktop.sh"

# 9. Deploy configuration files
run_stage "configure-dotfiles.sh"

# 10. Verify installed packages
run_stage "verify-packages.sh"

# 11. Verify the installation
run_stage "verify-installation.sh"

printf '\n'
printf '========================================\n'
printf 'MahdiOS installation stages completed.\n'
printf '========================================\n'
