```bash
#!/usr/bin/env bash
set -Eeuo pipefail

fail() {
    printf 'ERROR: %s\n' "$*" >&2
    exit 1
}

[[ "$EUID" -ne 0 ]] ||
    fail "Run this script as your regular user, not as root."

command -v systemctl >/dev/null 2>&1 ||
    fail "systemctl is not available."

printf '\nMahdiOS — Enable system services\n\n'
printf 'The following services will be enabled at boot:\n'
printf '  - NetworkManager.service\n'
printf '  - bluetooth.service\n\n'

read -r -p 'Continue? [y/N] ' answer
[[ "$answer" == [yY] || "$answer" == [yY][eE][sS] ]] || {
    printf 'Cancelled. No changes made.\n'
    exit 0
}

sudo systemctl enable --now NetworkManager.service
sudo systemctl enable --now bluetooth.service

printf '\nService setup completed.\n'
printf 'NetworkManager and Bluetooth are enabled and started.\n'
printf 'ufw should be enabled manually!'
```
