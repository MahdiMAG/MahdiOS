
#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
MANIFEST="$PROJECT_DIR/packages/core.txt"

[[ "$EUID" -ne 0 ]] || {
    printf 'ERROR: Run this script as your regular user, not as root.\n' >&2
    exit 1
}

[[ -f "$MANIFEST" ]] || {
    printf 'ERROR: Missing manifest: %s\n' "$MANIFEST" >&2
    exit 1
}

mapfile -t packages < <(
    sed 's/#.*//' "$MANIFEST" |
    awk 'NF { for (i = 1; i <= NF; i++) print $i }'
)

((${#packages[@]})) || {
    printf 'ERROR: No packages found in %s\n' "$MANIFEST" >&2
    exit 1
}

printf '\nMahdiOS — Core package installation\n\n'
printf 'The following packages will be installed or updated:\n'
printf '  %s\n' "${packages[@]}"
printf '\n'

read -r -p 'Continue? [y/N] ' answer
[[ "$answer" == [yY] || "$answer" == [yY][eE][sS] ]] || {
    printf 'Cancelled. No changes made.\n'
    exit 0
}

sudo pacman -S --needed -- "${packages[@]}"

printf '\nCore package installation completed.\n'
