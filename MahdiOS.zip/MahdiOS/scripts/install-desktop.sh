
#!/usr/bin/env bash
set -Eeuo pipefail

fail() {
    printf 'ERROR: %s\n' "$*" >&2
    exit 1
}

# Do not run the installer as root.
[[ "$EUID" -ne 0 ]] ||
    fail "Run this script as your regular user, not as root."

# Check required commands.
for cmd in pacman sudo curl sh; do
    command -v "$cmd" >/dev/null 2>&1 ||
        fail "Required command not found: $cmd"
done

# Packages recommended for a Niri desktop.
packages=(
    curl
    fuzzel
    mako
    waybar
    xdg-desktop-portal-gtk
    xdg-desktop-portal-gnome
    alacritty
    swaybg
    swayidle
    swaylock
    xwayland-satellite
    udiskie
)

printf '\nMahdiOS — Desktop setup\n\n'
printf 'Packages to install or update:\n'
printf '  %s\n' "${packages[@]}"
printf '\nThe official DankMaterialShell installer will run afterward.\n'
printf 'Its interactive prompts will be preserved.\n\n'

read -r -p 'Continue? [y/N] ' answer
[[ "$answer" == [yY] || "$answer" == [yY][eE][sS] ]] || {
    printf 'Cancelled. No changes made.\n'
    exit 0
}

# Install the required packages.
sudo pacman -S --needed -- "${packages[@]}"

printf '\nPackage installation completed.\n'
printf 'Starting the official DankMaterialShell installer...\n\n'

# Run the official installer as the regular user.
curl -fsSL https://install.danklinux.com | sh

printf '\nDankMaterialShell installer exited successfully.\n'
printf 'Follow any remaining instructions from the installer.\n'
