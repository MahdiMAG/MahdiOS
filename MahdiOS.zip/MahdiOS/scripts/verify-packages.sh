
#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
failed=0

# Verify that every package in a manifest is installed.
check_package() {
    local package="$1"

    if pacman -Q "$package" >/dev/null 2>&1; then
        printf 'OK: %s is installed\n' "$package"
    else
        printf 'MISSING: %s is not installed\n' "$package"
        failed=1
    fi
}

for manifest in "$PROJECT_DIR"/packages/*.txt; do
    [[ -f "$manifest" ]] || continue

    while IFS= read -r package || [[ -n "$package" ]]; do
        package="${package%%#*}"
        package="${package#"${package%%[![:space:]]*}"}"
        package="${package%"${package##*[![:space:]]}"}"
        [[ -n "$package" ]] || continue

        case "$package" in
            base|base-devel)
                # These are package groups, not individual packages.
                while IFS= read -r member; do
                    [[ -n "$member" ]] && check_package "$member"
                done < <(
                    pacman -Qg "$package" 2>/dev/null |
                    awk '{print $2}' |
                    sort -u
                )
                ;;
            yay|cliamp|dsearch-bin)
                # AUR packages are checked by their installed package names.
                check_package "$package"
                ;;
            *)
                check_package "$package"
                ;;
        esac
    done < "$manifest"
done

if (( failed )); then
    printf '\nVerification failed: one or more packages are missing.\n' >&2
    exit 1
fi

printf '\nAll manifest packages verified as installed.\n'
